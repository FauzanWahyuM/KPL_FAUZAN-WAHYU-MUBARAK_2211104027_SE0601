﻿namespace modul3_2211104027
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblhasil = new System.Windows.Forms.Label();
            this.btnplus = new System.Windows.Forms.Button();
            this.btnsamadengan = new System.Windows.Forms.Button();
            this.btnnol = new System.Windows.Forms.Button();
            this.btnsatu = new System.Windows.Forms.Button();
            this.btndua = new System.Windows.Forms.Button();
            this.btntiga = new System.Windows.Forms.Button();
            this.btnempat = new System.Windows.Forms.Button();
            this.btnlima = new System.Windows.Forms.Button();
            this.btnenam = new System.Windows.Forms.Button();
            this.btntujuh = new System.Windows.Forms.Button();
            this.btndelapan = new System.Windows.Forms.Button();
            this.btnsembilan = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblhasil
            // 
            this.lblhasil.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhasil.Location = new System.Drawing.Point(12, 44);
            this.lblhasil.Name = "lblhasil";
            this.lblhasil.Size = new System.Drawing.Size(297, 40);
            this.lblhasil.TabIndex = 0;
            this.lblhasil.Text = "Hasil :";
            this.lblhasil.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnplus
            // 
            this.btnplus.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnplus.Location = new System.Drawing.Point(12, 108);
            this.btnplus.Name = "btnplus";
            this.btnplus.Size = new System.Drawing.Size(95, 54);
            this.btnplus.TabIndex = 1;
            this.btnplus.Text = "+";
            this.btnplus.UseVisualStyleBackColor = true;
            this.btnplus.Click += new System.EventHandler(this.btnplus_Click);
            // 
            // btnsamadengan
            // 
            this.btnsamadengan.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsamadengan.Location = new System.Drawing.Point(113, 108);
            this.btnsamadengan.Name = "btnsamadengan";
            this.btnsamadengan.Size = new System.Drawing.Size(95, 54);
            this.btnsamadengan.TabIndex = 2;
            this.btnsamadengan.Text = "=";
            this.btnsamadengan.UseVisualStyleBackColor = true;
            this.btnsamadengan.Click += new System.EventHandler(this.btnsamadengan_Click);
            // 
            // btnnol
            // 
            this.btnnol.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnol.Location = new System.Drawing.Point(214, 108);
            this.btnnol.Name = "btnnol";
            this.btnnol.Size = new System.Drawing.Size(95, 54);
            this.btnnol.TabIndex = 3;
            this.btnnol.Text = "0";
            this.btnnol.UseVisualStyleBackColor = true;
            this.btnnol.Click += new System.EventHandler(this.btnnol_Click);
            // 
            // btnsatu
            // 
            this.btnsatu.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsatu.Location = new System.Drawing.Point(12, 168);
            this.btnsatu.Name = "btnsatu";
            this.btnsatu.Size = new System.Drawing.Size(95, 54);
            this.btnsatu.TabIndex = 4;
            this.btnsatu.Text = "1";
            this.btnsatu.UseVisualStyleBackColor = true;
            this.btnsatu.Click += new System.EventHandler(this.btnsatu_Click);
            // 
            // btndua
            // 
            this.btndua.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndua.Location = new System.Drawing.Point(113, 168);
            this.btndua.Name = "btndua";
            this.btndua.Size = new System.Drawing.Size(95, 54);
            this.btndua.TabIndex = 5;
            this.btndua.Text = "2";
            this.btndua.UseVisualStyleBackColor = true;
            this.btndua.Click += new System.EventHandler(this.btndua_Click);
            // 
            // btntiga
            // 
            this.btntiga.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntiga.Location = new System.Drawing.Point(214, 168);
            this.btntiga.Name = "btntiga";
            this.btntiga.Size = new System.Drawing.Size(95, 54);
            this.btntiga.TabIndex = 6;
            this.btntiga.Text = "3";
            this.btntiga.UseVisualStyleBackColor = true;
            this.btntiga.Click += new System.EventHandler(this.btntiga_Click);
            // 
            // btnempat
            // 
            this.btnempat.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnempat.Location = new System.Drawing.Point(12, 228);
            this.btnempat.Name = "btnempat";
            this.btnempat.Size = new System.Drawing.Size(95, 54);
            this.btnempat.TabIndex = 7;
            this.btnempat.Text = "4";
            this.btnempat.UseVisualStyleBackColor = true;
            this.btnempat.Click += new System.EventHandler(this.btnempat_Click);
            // 
            // btnlima
            // 
            this.btnlima.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlima.Location = new System.Drawing.Point(113, 228);
            this.btnlima.Name = "btnlima";
            this.btnlima.Size = new System.Drawing.Size(95, 54);
            this.btnlima.TabIndex = 8;
            this.btnlima.Text = "5";
            this.btnlima.UseVisualStyleBackColor = true;
            this.btnlima.Click += new System.EventHandler(this.btnlima_Click);
            // 
            // btnenam
            // 
            this.btnenam.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnenam.Location = new System.Drawing.Point(214, 228);
            this.btnenam.Name = "btnenam";
            this.btnenam.Size = new System.Drawing.Size(95, 54);
            this.btnenam.TabIndex = 9;
            this.btnenam.Text = "6";
            this.btnenam.UseVisualStyleBackColor = true;
            this.btnenam.Click += new System.EventHandler(this.button9_Click);
            // 
            // btntujuh
            // 
            this.btntujuh.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntujuh.Location = new System.Drawing.Point(12, 288);
            this.btntujuh.Name = "btntujuh";
            this.btntujuh.Size = new System.Drawing.Size(95, 54);
            this.btntujuh.TabIndex = 10;
            this.btntujuh.Text = "7";
            this.btntujuh.UseVisualStyleBackColor = true;
            this.btntujuh.Click += new System.EventHandler(this.btntujuh_Click);
            // 
            // btndelapan
            // 
            this.btndelapan.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelapan.Location = new System.Drawing.Point(113, 288);
            this.btndelapan.Name = "btndelapan";
            this.btndelapan.Size = new System.Drawing.Size(95, 54);
            this.btndelapan.TabIndex = 11;
            this.btndelapan.Text = "8";
            this.btndelapan.UseVisualStyleBackColor = true;
            this.btndelapan.Click += new System.EventHandler(this.btndelapan_Click);
            // 
            // btnsembilan
            // 
            this.btnsembilan.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsembilan.Location = new System.Drawing.Point(214, 288);
            this.btnsembilan.Name = "btnsembilan";
            this.btnsembilan.Size = new System.Drawing.Size(95, 54);
            this.btnsembilan.TabIndex = 12;
            this.btnsembilan.Text = "9";
            this.btnsembilan.UseVisualStyleBackColor = true;
            this.btnsembilan.Click += new System.EventHandler(this.btnsembilan_Click);
            // 
            // btnclear
            // 
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.Location = new System.Drawing.Point(12, 348);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(297, 54);
            this.btnclear.TabIndex = 13;
            this.btnclear.Text = "C";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(325, 450);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnsembilan);
            this.Controls.Add(this.btndelapan);
            this.Controls.Add(this.btntujuh);
            this.Controls.Add(this.btnenam);
            this.Controls.Add(this.btnlima);
            this.Controls.Add(this.btnempat);
            this.Controls.Add(this.btntiga);
            this.Controls.Add(this.btndua);
            this.Controls.Add(this.btnsatu);
            this.Controls.Add(this.btnnol);
            this.Controls.Add(this.btnsamadengan);
            this.Controls.Add(this.btnplus);
            this.Controls.Add(this.lblhasil);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblhasil;
        private System.Windows.Forms.Button btnplus;
        private System.Windows.Forms.Button btnsamadengan;
        private System.Windows.Forms.Button btnnol;
        private System.Windows.Forms.Button btnsatu;
        private System.Windows.Forms.Button btndua;
        private System.Windows.Forms.Button btntiga;
        private System.Windows.Forms.Button btnempat;
        private System.Windows.Forms.Button btnlima;
        private System.Windows.Forms.Button btnenam;
        private System.Windows.Forms.Button btntujuh;
        private System.Windows.Forms.Button btndelapan;
        private System.Windows.Forms.Button btnsembilan;
        private System.Windows.Forms.Button btnclear;
    }
}

