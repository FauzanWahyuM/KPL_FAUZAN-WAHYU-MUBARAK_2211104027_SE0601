﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace modul3_2211104027
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string input = "";
        int angka1 = 0;
        bool tambah = false;


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            input += btn.Text;
            lblhasil.Text = input;
        }

        private void btnplus_Click(object sender, EventArgs e)
        {
            if (input != "")
            {
                angka1 = int.Parse(input);
                input = "";
                tambah = true;
                lblhasil.Text = "+";
            }
        }

        private void btnsamadengan_Click(object sender, EventArgs e)
        {
            if (input != "")
            {
                int angka2 = int.Parse(input);
                int hasil = 0;

                if (tambah)
                {
                    hasil = angka1 + angka2;
                    tambah = false;
                }

                lblhasil.Text = hasil.ToString();
                input = hasil.ToString(); 
            }
        }

        private void btnnol_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            input += btn.Text;
            lblhasil.Text = input; 
        }

        private void btnsatu_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            input += btn.Text;
            lblhasil.Text = input;
        }

        private void btndua_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            input += btn.Text;
            lblhasil.Text = input;
        }

        private void btntiga_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            input += btn.Text;
            lblhasil.Text = input;
        }

        private void btnempat_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            input += btn.Text;
            lblhasil.Text = input;
        }

        private void btnlima_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            input += btn.Text;
            lblhasil.Text = input;
        }

        private void btntujuh_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            input += btn.Text;
            lblhasil.Text = input;
        }

        private void btndelapan_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            input += btn.Text;
            lblhasil.Text = input;
        }

        private void btnsembilan_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            input += btn.Text;
            lblhasil.Text = input;
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            input = "";
            angka1 = 0;
            tambah = false;
            lblhasil.Text = "Hasil :";
        }
    }
}

