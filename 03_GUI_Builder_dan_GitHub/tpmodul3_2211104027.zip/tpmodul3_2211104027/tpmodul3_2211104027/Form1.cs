﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tpmodul3_2211104027
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnkirim_Click(object sender, EventArgs e)
        {
            string nama = txtinput.Text;
            lbloutput.Text = "Halo " + nama;
        }
    }
}
