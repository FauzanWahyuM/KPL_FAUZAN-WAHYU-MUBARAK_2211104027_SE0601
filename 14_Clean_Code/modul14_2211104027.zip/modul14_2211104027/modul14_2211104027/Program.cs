﻿using System;
using System.Collections.Generic;

namespace Modul14_2211104027
{
    public class Calculator
    {
        // Melakukan penjumlahan terhadap tiga angka bertipe generic
        public T SumThreeNumbers<T>(T a, T b, T c)
        {
            dynamic x = a, y = b, z = c;
            return (T)(x + y + z);
        }
    }

    public class SimpleDatabase<T>
    {
        private readonly List<T> _storedData;
        private readonly List<DateTime> _inputDates;

        public SimpleDatabase()
        {
            _storedData = new List<T>();
            _inputDates = new List<DateTime>();
        }

        // Menambahkan data baru dan mencatat waktu penambahan
        public void AddNewData(T data)
        {
            _storedData.Add(data);
            _inputDates.Add(DateTime.UtcNow);
        }

        // Menampilkan semua data beserta waktu inputnya
        public void PrintAllData()
        {
            for (int i = 0; i < _storedData.Count; i++)
            {
                Console.WriteLine($"Data {i + 1}: {_storedData[i]}, saved at UTC: {_inputDates[i]}");
            }
        }
    }

    public class Program
    {
        public static void Main()
        {
            // Contoh penggunaan generic method
            var calculator = new Calculator();
            int result = calculator.SumThreeNumbers(22, 40, 27);
            Console.WriteLine($"Sum Result: {result}");

            // Contoh penggunaan generic class
            var database = new SimpleDatabase<int>();
            database.AddNewData(22);
            database.AddNewData(40);
            database.AddNewData(27);
            database.PrintAllData();
        }
    }
}
