﻿using System.Text.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using modul15_2211104027;

public class UserService
{
    private readonly string filePath = "users.json";
    private List<User> users;

    public UserService()
    {
        users = LoadUsers();
    }

    private List<User> LoadUsers()
    {
        if (!File.Exists(filePath))
            return new List<User>();

        var json = File.ReadAllText(filePath);
        return JsonSerializer.Deserialize<List<User>>(json) ?? new List<User>();
    }

    private void SaveUsers()
    {
        var json = JsonSerializer.Serialize(users, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(filePath, json);
    }

    private string HashPassword(string password)
    {
        using var sha256 = SHA256.Create();
        byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
        return Convert.ToBase64String(bytes);
    }

    private bool IsValidUsername(string username)
    {
        return username.Length >= 4 && username.Length <= 20 && Regex.IsMatch(username, @"^[a-zA-Z]+$");
    }

    private bool IsValidPassword(string password, string username)
    {
        return password.Length >= 8 &&
               password.Length <= 20 &&
               Regex.IsMatch(password, @"[!@#$%^&*]") &&
               !password.Contains(username);
    }

    public void Register()
    {
        Console.Write("Masukkan username: ");
        string username = Console.ReadLine();

        if (!IsValidUsername(username))
        {
            Console.WriteLine("Username tidak valid. Hanya huruf dan panjang 4-20 karakter.");
            return;
        }

        Console.Write("Masukkan password: ");
        string password = Program.ReadPassword();

        if (!IsValidPassword(password, username))
        {
            Console.WriteLine("Password tidak valid. Panjang 8-20, harus ada simbol khusus (!@#$%^&*), dan tidak mengandung username.");
            return;
        }

        if (users.Any(u => u.Username == username))
        {
            Console.WriteLine("Username sudah terdaftar.");
            return;
        }

        users.Add(new User
        {
            Username = username,
            PasswordHash = HashPassword(password)
        });

        SaveUsers();
        Console.WriteLine("Registrasi berhasil!");
    }

    public void Login()
    {
        Console.Write("Masukkan username: ");
        string username = Console.ReadLine();

        Console.Write("Masukkan password: ");
        string password = Program.ReadPassword();

        string hashed = HashPassword(password);

        if (users.Any(u => u.Username == username && u.PasswordHash == hashed))
            Console.WriteLine("Login berhasil!");
        else
            Console.WriteLine("Username atau password salah.");
    }

    public static string ReadPassword()
    {
        StringBuilder password = new StringBuilder();
        ConsoleKeyInfo key;

        while (true)
        {
            key = Console.ReadKey(true);

            if (key.Key == ConsoleKey.Enter)
            {
                Console.WriteLine();
                break;
            }
            else if (key.Key == ConsoleKey.Backspace && password.Length > 0)
            {
                password.Remove(password.Length - 1, 1);
                Console.Write("\b \b"); // hapus satu karakter di layar
            }
            else if (!char.IsControl(key.KeyChar))
            {
                password.Append(key.KeyChar);
                Console.Write("*");
            }
        }

        return password.ToString();
    }

}
