﻿using System.Text;

class Program
{
    public static string ReadPassword()
    {
        StringBuilder password = new StringBuilder();
        ConsoleKeyInfo key;

        while (true)
        {
            key = Console.ReadKey(true);

            if (key.Key == ConsoleKey.Enter)
            {
                Console.WriteLine();
                break;
            }
            else if (key.Key == ConsoleKey.Backspace && password.Length > 0)
            {
                password.Remove(password.Length - 1, 1);
                Console.Write("\b \b");
            }
            else if (!char.IsControl(key.KeyChar))
            {
                password.Append(key.KeyChar);
                Console.Write("*");
            }
        }

        return password.ToString();
    }

    static void Main()
    {
        var userService = new UserService();

        while (true)
        {
            Console.WriteLine("\nMenu:");
            Console.WriteLine("1. Registrasi");
            Console.WriteLine("2. Login");
            Console.WriteLine("3. Keluar");
            Console.Write("Pilih opsi: ");
            string input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    userService.Register();
                    break;
                case "2":
                    userService.Login();
                    break;
                case "3":
                    return;
                default:
                    Console.WriteLine("Input tidak valid.");
                    break;
            }
        }
    }
}
