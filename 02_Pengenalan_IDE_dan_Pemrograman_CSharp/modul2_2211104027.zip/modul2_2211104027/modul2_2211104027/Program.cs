﻿using System;

class Program
{
    static void Main()
    {
        // Input nama
        Console.Write("Masukkan nama Anda: ");
        string nama = Console.ReadLine();
        Console.WriteLine($"Selamat datang, {nama}!");

        // Array dan output
        int[] data = new int[50];
        for (int i = 0; i < data.Length; i++)
        {
            data[i] = i;
            if (i % 6 == 0)
                Console.WriteLine($"{data[i]} #$#$");
            else if (i % 2 == 0)
                Console.WriteLine($"{data[i]} ##");
            else if (i % 3 == 0)
                Console.WriteLine($"{data[i]} $$");
            else
                Console.WriteLine($"{data[i]}");
        }

        // Cek bilangan prima
        Console.Write("Masukkan angka (1-10000): ");
        string input = Console.ReadLine();
        int angka = Convert.ToInt32(input);

        bool prima = true;
        if (angka <= 1)
        {
            prima = false;
        }
        else
        {
            for (int i = 2; i <= Math.Sqrt(angka); i++)
            {
                if (angka % i == 0)
                {
                    prima = false;
                    break;
                }
            }
        }

        if (prima)
            Console.WriteLine($"Angka {angka} merupakan bilangan prima");
        else
            Console.WriteLine($"Angka {angka} bukan merupakan bilangan prima");
    }
}
